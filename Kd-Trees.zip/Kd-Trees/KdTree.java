import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.StdDraw;

import java.util.ArrayList;

public class KdTree {
    private final boolean VERTICAL = true;
    private final boolean HORIZONTAL = false;
    private Node root;

    public KdTree() {
        root = null;
    }

    private class Node {
        private Point2D point;
        private boolean splitLine;
        private RectHV rect;
        private Node left;
        private Node right;
        private int count;

        public Node(Point2D p, boolean splitDirection, RectHV pointRect) {
            point = p;
            splitLine = splitDirection;
            rect = pointRect;
        }

        public Node(Point2D p, boolean splitDirection, RectHV pointRect, int size) {
            point = p;
            splitLine = splitDirection;
            rect = pointRect;
            count = size;
        }
    }

    public boolean isEmpty() {
        return root == null;
    }

    public int size() {
        return size(root);
    }

    private int size(Node x) {
        if (x == null) return 0;
        else return x.count;
    }

    public void insert(Point2D p) {
        if (p == null) throw new IllegalArgumentException("p doesn't exist");
        Point2D insertPoint = p;
        root = put(root, insertPoint, VERTICAL, new RectHV(0, 0, 1, 1));
    }

    /*private Node put(Node x, Point2D p, boolean split, RectHV rect) {
        if (x == null) {
            return new Node(p, split, rect, 1);
        }
        if (x.point.x() == p.x() && x.point.y() == p.y()) x.point = p;
        else if (x.splitLine == VERTICAL) {
            if (p.x() < x.point.x()) {
                RectHV tempRect = new RectHV(x.rect.xmin(), x.rect.ymin(), x.point.x(), x.rect.ymax());
                boolean splitDir = !x.splitLine;
                x.left = put(x.left, p, splitDir, tempRect);
            }
            if (p.x() >= x.point.x()) {
                RectHV tempRect = new RectHV(x.point.x(), x.rect.ymin(), x.rect.xmax(), x.rect.ymax());
                boolean splitDir = !x.splitLine;
                x.right = put(x.right, p, splitDir, tempRect);
            }
        } else if (x.splitLine == HORIZONTAL) {
            if (p.y() < x.point.y()) {
                RectHV tempRect = new RectHV(x.rect.xmin(), x.rect.ymin(), x.rect.xmax(), x.point.y());
                boolean splitDir = !x.splitLine;
                x.left = put(x.left, p, splitDir, tempRect);
            }
            if (p.y() >= x.point.y()) {
                RectHV tempRect = new RectHV(x.rect.xmin(), x.point.y(), x.rect.xmax(), x.rect.ymax());
                boolean splitDir = !x.splitLine;
                x.right = put(x.right, p, splitDir, tempRect);
            }
        }
        x.count = size(x.left) + size(x.right) + 1;
        return x;
    }*/

    private Node put(Node x, Point2D p, boolean split, RectHV rect) {
        if (x == null) {
            return new Node(p, split, rect, 1);
        }
        if (x.point.x() == p.x() && x.point.y() == p.y()) x.point = p;
        else if (x.splitLine == VERTICAL) {
            if ((p.x() < x.point.x()) || (p.x() == x.point.x() && p.y() < x.point.y())) {
                RectHV tempRect = new RectHV(x.rect.xmin(), x.rect.ymin(), x.point.x(), x.rect.ymax());
                boolean splitDir = !x.splitLine;
                x.left = put(x.left, p, splitDir, tempRect);
            }
            if ((p.x() > x.point.x()) || (p.x() == x.point.x() && p.y() > x.point.y())) {
                RectHV tempRect = new RectHV(x.point.x(), x.rect.ymin(), x.rect.xmax(), x.rect.ymax());
                boolean splitDir = !x.splitLine;
                x.right = put(x.right, p, splitDir, tempRect);
            }
        } else if (x.splitLine == HORIZONTAL) {
            if ((p.y() < x.point.y()) || (p.y() == x.point.y() && p.x() < x.point.x())) {
                RectHV tempRect = new RectHV(x.rect.xmin(), x.rect.ymin(), x.rect.xmax(), x.point.y());
                boolean splitDir = !x.splitLine;
                x.left = put(x.left, p, splitDir, tempRect);
            }
            if ((p.y() > x.point.y()) || (p.y() == x.point.y() && p.x() > x.point.x())) {
                RectHV tempRect = new RectHV(x.rect.xmin(), x.point.y(), x.rect.xmax(), x.rect.ymax());
                boolean splitDir = !x.splitLine;
                x.right = put(x.right, p, splitDir, tempRect);
            }
        }
        x.count = size(x.left) + size(x.right) + 1;
        return x;
    }

    public boolean contains(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException("p doesn't exist");
        }
        Point2D checkPoint = p;
        Node x = root;
        while (x != null) {
            if (x.point.x() == checkPoint.x() && x.point.y() == checkPoint.y()) return true;
            else if (x.splitLine == VERTICAL) {
                if ((checkPoint.x() < x.point.x()) || (checkPoint.x() == x.point.x() && checkPoint.y() < x.point.y()))
                    x = x.left;
                else x = x.right;
            } else {
                if ((checkPoint.y() < x.point.y()) || (checkPoint.y() == x.point.y() && checkPoint.x() < x.point.x()))
                    x = x.left;
                else x = x.right;
            }
        }
        return false;
    }

    public void draw() {
        for (Node node : nodesInTree()) {
            StdDraw.setPenColor(StdDraw.BLACK);
            StdDraw.point(node.point.x(), node.point.y());
            if (node.splitLine == VERTICAL) {
                StdDraw.setPenColor(StdDraw.RED);
                StdDraw.line(node.point.x(), node.rect.ymin(), node.point.x(), node.rect.ymax());
            }
            if (node.splitLine == HORIZONTAL) {
                StdDraw.setPenColor(StdDraw.BLUE);
                StdDraw.line(node.rect.xmin(), node.point.y(), node.rect.xmax(), node.point.y());
            }
        }
    }

    private Iterable<Node> nodesInTree() {
        Queue<Node> q = new Queue<>();
        inorder(root, q);
        return q;
    }

    private void inorder(Node x, Queue<Node> q) {
        if (x == null) return;
        inorder(x.left, q);
        q.enqueue(x);
        inorder(x.right, q);
    }

    public Iterable<Point2D> range(RectHV rect) {
        if (rect == null) {
            throw new IllegalArgumentException("rect doesn't exist");
        }
        RectHV checkRect = rect;
        ArrayList<Point2D> pointsInRange = new ArrayList<Point2D>();
        searchPointInRange(root, checkRect, pointsInRange);
        return pointsInRange;
    }

    private void searchPointInRange(Node x, RectHV rect, ArrayList<Point2D> pointsInRange) {
        if (x == null || !rect.intersects(x.rect)) return;
        if (rect.contains(x.point)) pointsInRange.add(x.point);
        searchPointInRange(x.left, rect, pointsInRange);
        searchPointInRange(x.right, rect, pointsInRange);
    }

    public Point2D nearest(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException("p doesn't exist");
        }
        if (isEmpty()) return null;
        if (contains(p)) return p;
        Point2D checkPoint = p;
        ArrayList<Point2D> nearest = new ArrayList<>();
        findNearestPoint(root, checkPoint, nearest);
        Point2D nearestPoint = nearest.get(0);
        return nearestPoint;
    }

    private void findNearestPoint(Node x, Point2D p, ArrayList<Point2D> nearest) {
        if (nearest.isEmpty()) nearest.add(x.point);
        if (x == null || (x != root && x.rect.distanceSquaredTo(p) >= p.distanceSquaredTo(nearest.get(0)))) return;
        if (p.distanceSquaredTo(x.point) < p.distanceSquaredTo(nearest.get(0))) {
            nearest.remove(0);
            nearest.add(x.point);
        }
        if (x.splitLine == VERTICAL) {
            if ((p.x() < x.point.x()) || (p.x() == x.point.x() && p.y() < x.point.y())) {
                findNearestPoint(x.left, p, nearest);
                findNearestPoint(x.right, p, nearest);
            } else {
                findNearestPoint(x.right, p, nearest);
                findNearestPoint(x.left, p, nearest);
            }
        }
        if (x.splitLine == HORIZONTAL) {
            if ((p.y() < x.point.y()) || (p.y() == x.point.y() && p.x() < x.point.x())) {
                findNearestPoint(x.left, p, nearest);
                findNearestPoint(x.right, p, nearest);
            } else {
                findNearestPoint(x.right, p, nearest);
                findNearestPoint(x.left, p, nearest);
            }
        }
    }
}

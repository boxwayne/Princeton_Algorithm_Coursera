import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.SET;
import edu.princeton.cs.algs4.StdDraw;

import java.util.ArrayList;


public class PointSET {
    private SET<Point2D> pointTree;

    public PointSET() {
        pointTree = new SET<>();
    }

    public boolean isEmpty() {
        return pointTree.isEmpty();
    }

    public int size() {
        return pointTree.size();
    }

    public void insert(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException("p doesn't exist");
        }
        if (contains(p)) return;
        pointTree.add(p);
    }

    public boolean contains(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException("p doesn't exist");
        }
        return pointTree.contains(p);
    }

    public void draw() {
        for (Point2D point : pointTree) {
            StdDraw.setPenColor(StdDraw.BLACK);
            StdDraw.point(point.x(), point.y());
        }
    }


    public Iterable<Point2D> range(RectHV rect) {
        if (rect == null) {
            throw new IllegalArgumentException("rect doesn't exist");
        }
        ArrayList<Point2D> pointsInRange = new ArrayList<>();
        for (Point2D point : pointTree) {
            if (rect.contains(point)) {
                pointsInRange.add(point);
            }
        }
        return pointsInRange;
    }

    public Point2D nearest(Point2D p) {
        if (p == null) {
            throw new IllegalArgumentException("p doesn't exist");
        }
        if (pointTree.isEmpty()) {
            return null;
        }
        if (contains(p)) {
            return p;
        }
        Point2D nearestPoint = null;
        for (Point2D point : pointTree) {
            if (nearestPoint == null || p.distanceSquaredTo(point) < p.distanceSquaredTo(nearestPoint)) {
                nearestPoint = point;
            }
        }
        return nearestPoint;
    }
}

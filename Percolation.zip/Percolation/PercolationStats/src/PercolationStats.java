import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private int trials;
    private double[] fractOfOpen;
    private double mean;
    private double stddev;
    private double confidenceHi;
    private double confidenceLo;

    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0) {
            throw new IllegalArgumentException("The value of input is illegal");
        }
        this.trials = trials;
        fractOfOpen = new double[trials];
        for (int i = 0; i < trials; i++) {
            Percolation perc = new Percolation(n);
            while (!perc.percolates()) {
                int row = StdRandom.uniform(n) + 1;
                int col = StdRandom.uniform(n) + 1;
                if (!perc.isOpen(row, col)) {
                    perc.open(row, col);
                }
            }
            fractOfOpen[i] = (double) perc.numberOfOpenSites() / (n * n);
        }
        mean = StdStats.mean(fractOfOpen);
        stddev = StdStats.stddev(fractOfOpen);
        confidenceHi = (mean + 1.96 * stddev / Math.sqrt((double) trials));
        confidenceLo = (mean - 1.96 * stddev / Math.sqrt((double) trials));
    }

    public double mean() {
        return mean;
    }

    public double stddev() {
        if (trials == 1) {
            return Double.NaN;
        }
        return stddev;
    }

    public double confidenceLo() {
        if (trials == 1) {
            return Double.NaN;
        }
        return confidenceLo;
    }

    public double confidenceHi() {
        if (trials == 1) {
            return Double.NaN;
        }
        return confidenceHi;
    }

    public static void main(String[] args) {
        PercolationStats instanceOfStats = new PercolationStats(20, 100);
        StdOut.println("the mean value of p is " + instanceOfStats.mean());
        StdOut.println("the mean value of s is " + instanceOfStats.stddev());
        StdOut.println("the mean value of lo is " + instanceOfStats.confidenceLo());
        StdOut.println("the mean value of hi is " + instanceOfStats.confidenceHi());
    }
}


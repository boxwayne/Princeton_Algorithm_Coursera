
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private static final int VIRTUAL_TOP = 0;
    private static final boolean IS_OPEN = true;
    private int n;
    private int gridNumber;
    private int numOfOpenGrid;
    private int virtualBottom;
    private boolean[] grid;
    private WeightedQuickUnionUF withVirtualBottom;
    private WeightedQuickUnionUF withoutVirtualBottom;

    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("the value of n is illegal");
        }
        this.n = n;
        gridNumber = n * n + 2;
        virtualBottom = n * n + 1;
        withVirtualBottom = new WeightedQuickUnionUF(gridNumber);
        withoutVirtualBottom = new WeightedQuickUnionUF(gridNumber - 1);
        grid = new boolean[gridNumber];
        numOfOpenGrid = 0;
        for (int i = VIRTUAL_TOP; i < gridNumber; i++) {
            grid[i] = !IS_OPEN;
        }
        grid[VIRTUAL_TOP] = IS_OPEN;
        grid[virtualBottom] = IS_OPEN;
    }

    private boolean positionIsValid(int row, int col) {
        return ((0 < row) && (row <= n) && (0 < col) && (col <= n));
    }

    private int xyTo1D(int row, int col) {
         int i;
         i = (row - 1) * n + col;
         return i;
    }

    private void connectWithAdjacentGrid(int row, int col) {
        if (!positionIsValid(row, col)) {
            throw new IllegalArgumentException("the position is out of the boundary");
        }
        int leftGrid, rightGrid, upperGrid, lowerGrid;
        if (positionIsValid(row, col - 1)) {
            if (isOpen(row, col - 1)) {
                leftGrid = xyTo1D(row, col - 1);
                withVirtualBottom.union(leftGrid, xyTo1D(row, col));
                withoutVirtualBottom.union(leftGrid, xyTo1D(row, col));
            }
        }
        if (positionIsValid(row, col + 1)) {
            if (isOpen(row, col + 1)) {
                rightGrid = xyTo1D(row, col + 1);
                withVirtualBottom.union(rightGrid, xyTo1D(row, col));
                withoutVirtualBottom.union(rightGrid, xyTo1D(row, col));
            }
        }
        if (positionIsValid(row - 1, col)) {
            if (isOpen(row - 1, col)) {
                upperGrid = xyTo1D(row - 1, col);
                withVirtualBottom.union(upperGrid, xyTo1D(row, col));
                withoutVirtualBottom.union(upperGrid, xyTo1D(row, col));
            }
        }
        if (positionIsValid(row + 1, col)) {
            if (isOpen(row + 1, col)) {
                lowerGrid = xyTo1D(row + 1, col);
                withVirtualBottom.union(lowerGrid, xyTo1D(row, col));
                withoutVirtualBottom.union(lowerGrid, xyTo1D(row, col));
            }
        }
    }

    public boolean isOpen(int row, int col) {
        if (!positionIsValid(row, col)) {
            throw new IllegalArgumentException("the position is out of the boundary");
        }
        return grid[xyTo1D(row, col)];
    }

    public boolean isFull(int row, int col) {
        if (!positionIsValid(row, col)) {
            throw new IllegalArgumentException("the position is out of the boundary");
        }
        return withoutVirtualBottom.connected(VIRTUAL_TOP, xyTo1D(row, col));
    }

    public int numberOfOpenSites() {
        return numOfOpenGrid;
    }

    public boolean percolates() {
        return withVirtualBottom.connected(VIRTUAL_TOP, virtualBottom);
    }

    public void open(int row, int col) {
        if (!positionIsValid(row, col)) {
            throw new IllegalArgumentException("the position is out of the boundary");
        }
        if (n == 1) {
            withVirtualBottom.union(VIRTUAL_TOP, virtualBottom);
        }
        if (!isOpen(row, col)) {
            grid[xyTo1D(row, col)] = IS_OPEN;
            connectWithAdjacentGrid(row, col);
            numOfOpenGrid++;
            if (row == 1) {
                withVirtualBottom.union(VIRTUAL_TOP, xyTo1D(row, col));
                withoutVirtualBottom.union(VIRTUAL_TOP, xyTo1D(row, col));
            }
            else if (row == n) {
                withVirtualBottom.union(virtualBottom, xyTo1D(row, col));
            }
        }
    }

    public static void main(String[] args) {
        Percolation gridSystem = new Percolation(3);
        gridSystem.open(1, 1);
        gridSystem.open(2, 1);
        gridSystem.open(2, 2);
        gridSystem.open(3, 3);
        gridSystem.open(3, 2);
        StdOut.println("Does system percolate?" + gridSystem.percolates());
    }
}

import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;
import java.util.Comparator;

public class Solver {
    private int totalmoves;
    private boolean isSolvable;
    private Node searchNode;
    /*private Node searchNodeTwin;*/
    private Stack<Board> solution = new Stack<Board>();

    private class Node implements Comparable<Node>{
        private int moves;
        private int priority;
        private Board board;
        private boolean isTwin;
        private Node previous;

        Node(Board b, boolean isTw) {
            board = b;
            moves = 0;
            previous = null;
            isTwin = isTw;
            priority = board.manhattan() + moves;
        }

        /*public Node(Board b) {
            board = b;
            moves = 0;
            previous = null;
            priority = board.manhattan() + moves;
        }*/

        public Node(Board b, Node previous) {
            board = b;
            moves = previous.moves + 1;
            this.previous = previous;
            isTwin = previous.isTwin;
            priority = board.manhattan() + moves;
        }

        public int compareTo(Node that) {
            if (this.priority == that.priority) return this.board.manhattan() - that.board.manhattan();
            else return this.priority - that.priority;
        }
    }

    public Solver(Board initial) {
        if (initial == null) throw new IllegalArgumentException("the initial board is null");

        MinPQ<Node> boardMinPQ = new MinPQ<Node>();
        /*MinPQ<Node> boardMinPQ = new MinPQ<>(new Comparator<Node>() {
            public int compare(Node n1, Node n2) {
                if (n1.priority == n2.priority) return n1.board.manhattan() - n2.board.manhattan();
                else return n1.priority - n2.priority;
            }
        });*/

        /*MinPQ<Node> boardMinPQTwin = new MinPQ<>(new Comparator<Node>() {
            public int compare(Node n1, Node n2) {
                if (n1.priority == n2.priority) return n1.board.manhattan() - n2.board.manhattan();
                else return n1.priority - n2.priority;
            }
        });*/

        isSolvable = false;
        boardMinPQ.insert(new Node(initial, false));
        boardMinPQ.insert(new Node(initial.twin(), true));
        /*boardMinPQ.insert(new Node(initial));
        boardMinPQTwin.insert(new Node(initial.twin()));*/

        while (true) {
            searchNode = boardMinPQ.delMin();
            /*searchNodeTwin = boardMinPQTwin.delMin();*/
            if (searchNode.board.isGoal()) {
                /*isSolvable = true;
                totalmoves = searchNode.moves;
                break;*/
                if (!searchNode.isTwin) {
                    isSolvable = true;
                    totalmoves = searchNode.moves;
                    break;
                }
                else {
                    totalmoves = -1;
                    break;
                }
            }
            /*if (searchNodeTwin.board.isGoal()) {
                totalmoves = -1;
                break;
            }*/
            for (Board neighbor : searchNode.board.neighbors()) {
                if (searchNode.previous == null || !neighbor.equals(searchNode.previous.board)) {
                    boardMinPQ.insert(new Node(neighbor, searchNode));
                }
            }
            /*for (Board neighbor: searchNodeTwin.board.neighbors()) {
                if (searchNodeTwin.previous == null || !neighbor.equals(searchNodeTwin.previous.board)) {
                    boardMinPQTwin.insert(new Node(neighbor, searchNode));
                }
            }*/
        }
        if (isSolvable) {
            while (searchNode != null) {
                solution.push(searchNode.board);
                searchNode = searchNode.previous;
            }
        }
        else {
            solution = null;
        }
    }

    public boolean isSolvable() {
        return isSolvable;
    }

    public int moves() {
        return totalmoves;
    }

    public Iterable<Board> solution() {
        return solution;
    }

    public static void main(String args[]) {
        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                tiles[i][j] = in.readInt();
        Board initial = new Board(tiles);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }
}
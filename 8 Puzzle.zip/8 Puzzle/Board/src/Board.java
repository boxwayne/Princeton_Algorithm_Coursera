import java.util.ArrayList;
import edu.princeton.cs.algs4.StdRandom;

public class Board {
    private final int[] tiles;
    private final int dimension;

    public Board(int[][] tiles) {
        dimension = tiles.length;
        this.tiles = new int[dimension * dimension];
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                this.tiles[xyTo2D(i, j)] = tiles[i][j];
            }
        }
    }

    private int xyTo2D(int i, int j) {
        return dimension * i + j;
    }

    public String toString() {
        int n = dimension;
        String board = n + " " + "\n" + " ";
        for(int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                board = board + tiles[xyTo2D(i, j)] + " ";
            }
            board = board + "\n" + " ";
        }
        return board;
    }

    public int dimension() {
        return dimension;
    }

    public int hamming() {
        int hammingdis = 0;
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                if (tiles[xyTo2D(i, j)] != dimension * i + j + 1) hammingdis++;
            }
        }
        hammingdis--;
        return hammingdis;
    }

    public int manhattan() {
        int manhattandis = 0;
        int row;
        int col;
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                if (tiles[xyTo2D(i, j)] == 0) continue;
                else {
                    row = (tiles[xyTo2D(i, j)] - 1) / dimension;
                    col = (tiles[xyTo2D(i, j)] - 1) % dimension;
                    manhattandis = manhattandis + Math.abs(row - i) + Math.abs(col - j);
                }
            }
        }
        return manhattandis;
    }

    public boolean isGoal() {
        boolean isGoal = true;
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                if (i == dimension - 1 && j == dimension - 1) break;
                if (tiles[xyTo2D(i, j)] != dimension * i + j + 1) {
                    isGoal = false;
                    break;
                }
            }
        }
        return isGoal;
    }

    public boolean equals(Object y) {
        if (y == null) return false;
        if (y == this) return true;
        if (y.getClass().isInstance(this)) {
            Board that = (Board) y;
            if (that.dimension() != this.dimension()) return false;
            for (int i = 0; i < dimension; i++) {
                for (int j = 0; j < dimension; j++) {
                    if (that.tiles[xyTo2D(i, j)] != this.tiles[xyTo2D(i, j)]) return false;
                }
            }
        }
        else {
            return false;
        }
        return true;
    }

    private int[] getBlank() {
        int[] coordin = new int[2];
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                if (tiles[xyTo2D(i, j)] == 0) {
                    coordin[0] = i;
                    coordin[1] = j;
                    break;
                }
            }
        }
        return coordin;
    }

    private Board swap(int a, int b) {
        int[][] temptiles = new int[dimension][dimension];
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                temptiles[i][j] = tiles[xyTo2D(i, j)];
            }
        }
        int temp = temptiles[a / dimension][a % dimension];
        temptiles[a / dimension][a % dimension] = temptiles[b / dimension][b % dimension];
        temptiles[b / dimension][b % dimension] = temp;
        Board swapBoard = new Board(temptiles);
        return swapBoard;
    }

    public Iterable<Board> neighbors() {
        ArrayList<Board> boardArrayList = new ArrayList<>();
        int i = getBlank()[0];
        int j = getBlank()[1];
        if (i > 0) {
            Board neighbor = swap(xyTo2D(i, j), xyTo2D(i - 1, j));
            boardArrayList.add(neighbor);
        }
        if (i < dimension - 1) {
            Board neighbor = swap(xyTo2D(i, j), xyTo2D(i + 1, j));
            boardArrayList.add(neighbor);
        }
        if (j > 0) {
            Board neighbor = swap(xyTo2D(i, j), xyTo2D(i, j - 1));
            boardArrayList.add(neighbor);
        }
        if (j < dimension - 1) {
            Board neighbor = swap(xyTo2D(i, j), xyTo2D(i, j + 1));
            boardArrayList.add(neighbor);
        }
        return boardArrayList;
    }

    public Board twin() {
        if (tiles[0] == 0 || tiles[1] == 0)
            return swap(dimension * dimension - 2, dimension * dimension - 1);
        else
            return swap(0, 1);
    }

    public static void main(String args[]) {
        int[][] tiles1 = {{0, 4, 5},
                          {3, 8, 2},
                          {1, 7, 6}};
        int[][] tiles2 = {{10, 1, 11, 19, 20},
                          {5, 8, 15, 21, 22},
                          {7, 12, 3, 23, 24},
                          {9, 17, 0, 2, 13},
                          {14, 4, 16, 6, 18}};
        Board board1 = new Board(tiles1);
        Board board2 = new Board(tiles2);
        System.out.println(board1.toString());
        System.out.println(board1.hamming());
        System.out.println(board1.manhattan());
        System.out.println(board2.getBlank()[0]);
        System.out.println(board2.getBlank()[1]);
        System.out.println(board1.isGoal());
        System.out.println(board1.twin().toString());
        System.out.println(board1.equals(board2));
        for (Board b: board2.neighbors()) {
            System.out.println(b.toString());
        }
    }
}

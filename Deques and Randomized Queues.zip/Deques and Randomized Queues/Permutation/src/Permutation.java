import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdIn;

public class Permutation {
    public static void main(String[] args) {
        int k = Integer.parseInt(args[0]);
        RandomizedQueue<String> stringRandomizedQueue = new RandomizedQueue<String>();
        while (!StdIn.isEmpty())
            stringRandomizedQueue.enqueue(StdIn.readString());
        if (k > stringRandomizedQueue.size())
            throw new IllegalArgumentException("the number of printed can not be greater than that of total");
        for (int i = 0; i < k; i++)
            StdOut.println(stringRandomizedQueue.dequeue());
    }
}

import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private int n;
    private int length;
    private Item[] s;

    public RandomizedQueue() {
        n = 0;
        length = n + 1;
        s = (Item[]) new Object[length];
    }

    public boolean isEmpty() { return n == 0; }

    public int size() { return n; }

    public void enqueue(Item item) {
        if (item == null) throw new IllegalArgumentException("no item assigned");
        if (n == length) resize(2 * length);
        s[n++] = item;
    }

    public Item dequeue() {
        if (isEmpty()) throw new NoSuchElementException("the RandomizedQueue is empty");
        int label = randomLabel(n);
        Item item = s[label];
        if (label != n - 1) s[label] = s[n - 1];
        s[n - 1] = null;
        --n;
        if (n > 0 && n == length/4) resize(length/2);
        return item;
    }

    private int randomLabel(int i) {
        return StdRandom.uniform(i);
    }

    private void resize(int capacity) {
        Item[] copy = (Item[]) new Object[capacity];
        length = capacity;
        for (int i = 0; i < n; i++) { copy[i] = s[i]; }
        s = copy;
    }

    public Item sample() {
        if (isEmpty()) throw new NoSuchElementException("the RandomizedQueue is empty");
        int label = randomLabel(n);
        Item item = s[label];
        return item;
    }

    public Iterator<Item> iterator() {
        return new RandomizedQueueIterator();
    }

    private class RandomizedQueueIterator implements Iterator<Item> {
        private int i = n;
        Item[] randQueue;

        public RandomizedQueueIterator() {
            randQueue = (Item[]) new Object[i];
            for (int j = 0; j < i; j++)
                randQueue[j] = s[j];
        }

        public boolean hasNext() { return i > 0; }

        public void remove() { throw new UnsupportedOperationException("this operation is unsupported"); }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException("no more element in RandomizedQueue");
            int j = randomLabel(i);
            Item item = randQueue[j];
            --i;
            if (j != i) {
                randQueue[j] = randQueue[i];
                randQueue[i] = item;
            }
            return item;
        }
    }

    public static void main(String[] args) {
        RandomizedQueue<String> stringRandomizedQueue = new RandomizedQueue<String>();
        StdOut.println("Is empty?" + stringRandomizedQueue.isEmpty());
        StdOut.println("number of elements" + stringRandomizedQueue.size());
        stringRandomizedQueue.enqueue("1");
        StdOut.println("length of array" + stringRandomizedQueue.length);
        stringRandomizedQueue.enqueue("2");
        StdOut.println("length of array" + stringRandomizedQueue.length);
        stringRandomizedQueue.enqueue("3");
        StdOut.println("length of array" + stringRandomizedQueue.length);
        stringRandomizedQueue.enqueue("4");
        StdOut.println("length of array" + stringRandomizedQueue.length);
        stringRandomizedQueue.enqueue("5");
        StdOut.println("length of array" + stringRandomizedQueue.length);
        stringRandomizedQueue.enqueue("6");
        StdOut.println("length of array" + stringRandomizedQueue.length);
        stringRandomizedQueue.enqueue("7");
        StdOut.println("length of array" + stringRandomizedQueue.length);
        stringRandomizedQueue.enqueue("8");
        StdOut.println("length of array" + stringRandomizedQueue.length);
        for (String s : stringRandomizedQueue)
            StdOut.println(s);
        StdOut.println("dequeue" + stringRandomizedQueue.dequeue());
        StdOut.println("dequeue" + stringRandomizedQueue.dequeue());
        StdOut.println("dequeue" + stringRandomizedQueue.dequeue());
        StdOut.println("Is empty?" + stringRandomizedQueue.isEmpty());
        StdOut.println("number of elements" + stringRandomizedQueue.size());
        StdOut.println("sampling" + stringRandomizedQueue.sample());
        StdOut.println("sampling" + stringRandomizedQueue.sample());
        for (String s : stringRandomizedQueue)
            StdOut.println(s);
        StdOut.println("dequeue" + stringRandomizedQueue.dequeue());
        StdOut.println("length of array" + stringRandomizedQueue.length);
        StdOut.println("dequeue" + stringRandomizedQueue.dequeue());
        StdOut.println("length of array" + stringRandomizedQueue.length);
        StdOut.println("dequeue" + stringRandomizedQueue.dequeue());
        StdOut.println("length of array" + stringRandomizedQueue.length);
    }
}

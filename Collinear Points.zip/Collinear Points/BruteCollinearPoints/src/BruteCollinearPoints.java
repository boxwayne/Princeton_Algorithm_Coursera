import java.util.Arrays;
import java.util.ArrayList;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

public class BruteCollinearPoints {
    private final Point[] pts;
    private final ArrayList<LineSegment> sgms = new ArrayList<LineSegment>();

    public BruteCollinearPoints(Point[] points) {
        checkNullElement(points);
        pts = new Point[points.length];
        for (int i = 0; i < pts.length; i++) {
            pts[i] = points[i];
        }
        checkRepeatedElement(pts);
        for (int p = 0; p < pts.length - 3; p++) {
            for (int q = p + 1; q < pts.length - 2; q++) {
                for (int r = q + 1; r < pts.length - 1; r++) {
                    if (Double.compare(pts[p].slopeTo(pts[q]), pts[q].slopeTo(pts[r])) != 0) {
                        continue;
                    }
                    for (int s = r + 1; s < pts.length; s++) {
                        if (Double.compare(pts[q].slopeTo(pts[r]), pts[r].slopeTo(pts[s])) != 0) {
                            continue;
                        }
                        if (Double.compare(pts[q].slopeTo(pts[r]), pts[r].slopeTo(pts[s])) == 0) {
                            LineSegment lsgm = new LineSegment(pts[p], pts[s]);
                            sgms.add(lsgm);
                        }
                    }
                }
            }
        }

    }

    private void checkNullElement(Point[] points) {
        if (points == null) throw new IllegalArgumentException("the array is empty");
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) {
                throw new IllegalArgumentException("null element exists");
            }
        }
    }

    private void checkRepeatedElement(Point[] points) {
        Arrays.sort(points);
        for (int i = 0; i < points.length - 1; i++) {
            if (points[i].compareTo(points[i+1]) == 0) throw new IllegalArgumentException("repeated element exists");
        }
    }

    public int numberOfSegments() {
        return sgms.size();
    }

    public LineSegment[] segments() {
        LineSegment[] segments = new LineSegment[sgms.size()];
        int i = 0;
        for (LineSegment ls: sgms) {
            segments[i++] = ls;
        }
        return segments;
    }

    public static void main(String[] args) {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        BruteCollinearPoints collinear = new BruteCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}

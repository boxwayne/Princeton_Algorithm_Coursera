import java.util.Comparator;
import edu.princeton.cs.algs4.StdDraw;

public class Point implements Comparable<Point> {

    private final int x;     // x-coordinate of this point
    private final int y;     // y-coordinate of this point

    public Point(int x, int y) {
        /* DO NOT MODIFY */
        this.x = x;
        this.y = y;
    }

    public void draw() {
        /* DO NOT MODIFY */
        StdDraw.point(x, y);
    }

    public void drawTo(Point that) {
        /* DO NOT MODIFY */
        StdDraw.line(this.x, this.y, that.x, that.y);
    }

    public double slopeTo(Point that) {
        if (x == that.x && y != that.y) return + 1.0 / 0.0;
        else if (y == that.y && x != that.x) return +0.0;
        else if (x == that.x && y == that.y) return - 1.0 / 0.0;
        else return ((that.y - y) * 1.0)/(that.x - x);
    }

    public int compareTo(Point that) {
        if (y < that.y) return -1;
        else if (y == that.y && x < that.x) return -1;
        else if (y == that.y && x == that.x) return 0;
        else return +1;
    }

    public Comparator<Point> slopeOrder() {
        return new BySlopeOrder();
    }

    private class BySlopeOrder implements Comparator<Point> {
        public int compare(Point p1, Point p2) {
            Double slope1 = slopeTo(p1);
            Double slope2 = slopeTo(p2);
            if (slope1 < slope2) return -1;
            else if (slope1 > slope2) return +1;
            else return 0;
        }
    }

    public String toString() {
        /* DO NOT MODIFY */
        return "(" + x + ", " + y + ")";
    }

    public static void main(String[] args) {
        Point origin = new Point(100, 100);
        origin.draw();
        System.out.println(origin.toString());
        Point p = new Point(136, 39);
        Point q = new Point(74, 169);
        p.draw();
        q.draw();
        origin.drawTo(p);
        origin.drawTo(q);
        System.out.println("slope to p:" + origin.slopeTo(p));
        System.out.println("slope to q:" + origin.slopeTo(q));
        System.out.println("compare to p:" + origin.compareTo(p));
        System.out.println("compare to q:" + origin.compareTo(q));
        System.out.println("slope op compare to oq:" + origin.slopeOrder().compare(p, q));
    }
}

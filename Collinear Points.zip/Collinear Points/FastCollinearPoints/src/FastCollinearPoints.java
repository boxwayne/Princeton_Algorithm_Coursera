import java.util.ArrayList;
import java.util.Comparator;
import java.util.Arrays;

import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

public class FastCollinearPoints {
    private Point[] pts;
    private ArrayList<LineSegment> sgms;

    public FastCollinearPoints(Point[] points) {
        int N = points.length;
        if (points == null) throw new IllegalArgumentException("the array is empty");
        for (int i = 0; i < N; i++) {
            if (points[i] == null) {
                throw new IllegalArgumentException("null element exists");
            }
        }
        pts = new Point[N];
        for (int i = 0; i < N; i++) {
            pts[i] = points[i];
        }
        Arrays.sort(pts);
        for (int i = 0; i < N - 1; i++) {
            if (pts[i].compareTo(pts[i+1]) == 0) throw new IllegalArgumentException("repeated element exists");
        }
        sgms = new ArrayList<LineSegment>();
        Point origin;
        Point[] tempts = new Point[N - 1];
        for (int p = 0; p < N; p++) {
            origin = pts[p];
            for (int j = 0; j < N; j++) {
                if (j < p) tempts[j] = pts[j];
                if (j > p) tempts[j - 1] = pts[j];
            }
            Arrays.sort(tempts, origin.slopeOrder());
            int start = 0;
            int numOfColl = 2;
            for (int i = 1; i < N - 1; i++) {
                double s1 = tempts[i - 1].slopeTo(origin);
                double s2 = tempts[i].slopeTo(origin);
                if (s1 == s2) {
                    numOfColl++;
                    if ((i == N - 2) && (numOfColl > 3)) {
                        if (origin.compareTo(tempts[start]) < 0) {
                            Point head = origin;
                            Point end = tempts[i];
                            LineSegment lineSeg = new LineSegment(head, end);
                            sgms.add(lineSeg);
                        }
                    }
                }
                else {
                    if ((numOfColl > 3) && (origin.compareTo(tempts[start]) < 0)) {
                        Point head = origin;
                        Point end = tempts[i - 1];
                        LineSegment lineSeg = new LineSegment(head, end);
                        sgms.add(lineSeg);
                    }
                    start = i;
                    numOfColl = 2;
                }
            }
        }
    }

    public int numberOfSegments() {
        return sgms.size();
    }

    public LineSegment[] segments() {
        LineSegment[] segments = new LineSegment[sgms.size()];
        int i = 0;
        for (LineSegment ls: sgms) {
            segments[i++] = ls;
        }
        return segments;
    }
}
